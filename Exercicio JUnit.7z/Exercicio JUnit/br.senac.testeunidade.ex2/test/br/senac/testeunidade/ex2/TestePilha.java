package br.senac.testeunidade.ex2;

import static org.junit.Assert.*;
import org.junit.Test;

public class TestePilha {

	
}
