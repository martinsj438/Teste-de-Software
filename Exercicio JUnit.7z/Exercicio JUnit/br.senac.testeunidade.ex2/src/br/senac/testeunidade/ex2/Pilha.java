package br.senac.testeunidade.ex2;

public class Pilha {

	int tamanhoMaximo;
	
	public void inicializar(int tamanhoMaximo) {
		this.tamanhoMaximo = tamanhoMaximo;
	}
	
	public boolean empilhar(int numero){
		Pilha inicia = new Pilha();
		inicia.inicializar(10);
		inicia.vazia();
	
	}
	
	public int desempilhar() throws IndexOutOfBoundsException {
		
	
	}
	
	public boolean cheia() {
		return false;
	}
	
	public boolean vazia() {
		return false;
	}
	
}
