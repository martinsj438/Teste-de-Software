package br.senac.testeunidade.ex1;

public class Triangulo {

	private int a, b, c;
	private TipoTriangulo tipo;
	
	public Triangulo(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public TipoTriangulo retornarTipo() {
		
			if(a<b+c && b<a+c && c<a+b) {
				
			if (a==b && b==c){
				return tipo.EQUILATERO;
			}
			else if (a==c && b!=c || a==c && c!=b || c==b && b!=a){
				return tipo.ISOCELES;
			}
			else if (a!= b && b !=c) {
				return tipo.ESCALENO;
			}
			else {
				return tipo.INVALIDO;
			}
		}
		return null;
	}
}