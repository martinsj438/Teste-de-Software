package br.senac.testeunidade.ex1;

public enum TipoTriangulo {

	EQUILATERO, ISOCELES, ESCALENO, INVALIDO;
	
}
